READ ME

ABOUT
"Portfolio Project" is a zip file containing all the necessary assets and code to generate a responsive web page that matches the provided layout design for this project. 

INSTRUCTIONS
1. Unzip the file "Portfolio Project"

2. Open the file index.html in a web browser and test responsive layout on varying screen sizes